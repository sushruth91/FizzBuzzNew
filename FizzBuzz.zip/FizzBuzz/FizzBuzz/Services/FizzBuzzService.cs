﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FizzBuzz.Services
{
    public class FizzBuzzService : IFizzBuzz
    {
        public List<string> GetResults(List<string> input)
        {
            List<string> result = new List<string>();
            foreach(string i in input)
            {
                if (Int32.TryParse(i, out int j))
                {
                    if (DivisiblebyNum(j,15))
                    {
                        result.Add("FizzBuzz");
                    }
                    else if (DivisiblebyNum(j, 3))
                    {
                        result.Add("Fizz");
                    }
                    else if (DivisiblebyNum(j, 5))
                    {
                        result.Add("Buzz");
                    }
                    else if (DivisiblebyNum(j, 7))
                    {
                        result.Add("Fizz - Buzz");
                    }
                    else
                    {
                        result.Add("Divided " + j + " by 3");
                        result.Add("Divided " + j + " by 5");
                        result.Add("Divided " + j + " by 7");
                    }

                }
                else
                {
                    result.Add("Invalid Item");
                }
            }

            return result;
        }

        public bool DivisiblebyNum(int num, int div)
        {
            if (num % div ==0)
            {
                return true;
            }
            return false;    
        }


    }
}
