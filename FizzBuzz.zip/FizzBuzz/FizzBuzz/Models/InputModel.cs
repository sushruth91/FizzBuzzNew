﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FizzBuzz.Models
{
    public class InputModel
    {
        public List<string> Input { get; set; }
    }
}
